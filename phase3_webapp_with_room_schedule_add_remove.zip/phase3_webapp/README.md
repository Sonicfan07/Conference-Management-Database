# Phase 3 Web Wrapper (Minimal)

This is a minimal Flask + HTML UI for your existing Phase 3 SQLite database.  
It does **not** change your schema or logic: it uses the same tables (including the M:N junction tables) and performs the same INSERT/DELETE/UPDATE operations through web forms.

## Quick start

1. Install Flask:
   ```bash
   pip install flask
   ```

2. Run the web app from this folder:
   ```bash
   python app.py
   ```

3. Open in your browser:
   - http://127.0.0.1:5000

## What’s included

- Browse Conferences and view Sessions per Conference
- Browse Sessions and create/delete Sessions
- Browse Speakers
- Browse RoomSchedule slots and update status (also logs to `LogEntry`)
- Assign M:N relationships:
  - Session ↔ RoomSchedule via `SessionRoomAssignment`
  - Session ↔ Speaker via `SpeakerAssignment`

## Notes

- `conference.db` is included and used directly.
- Flash messages show constraint errors (e.g., duplicate assignment) as user-friendly warnings.

