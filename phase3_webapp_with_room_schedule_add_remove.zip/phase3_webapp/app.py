from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, flash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = str(BASE_DIR / "conference.db")


def get_connection() -> sqlite3.Connection:
    """Open a SQLite connection with foreign keys enabled and Row objects."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def parse_date_yyyy_mm_dd(date_str: str) -> bool:
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


app = Flask(__name__)
app.config["SECRET_KEY"] = "phase3-demo-secret-key"


@app.get("/")
def home():
    return render_template("home.html")


@app.get("/conferences")
def conferences():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT conference_id, name, location, start_date, end_date FROM Conference ORDER BY conference_id"
        ).fetchall()
    return render_template("conferences.html", conferences=rows)


@app.get("/conferences/<int:conference_id>/sessions")
def conference_sessions(conference_id: int):
    with get_connection() as conn:
        conf = conn.execute(
            "SELECT conference_id, name, location, start_date, end_date FROM Conference WHERE conference_id = ?",
            (conference_id,),
        ).fetchone()
        sessions = conn.execute(
            "SELECT session_id, title, conference_id FROM Session WHERE conference_id = ? ORDER BY session_id",
            (conference_id,),
        ).fetchall()
    if conf is None:
        flash("Conference not found.", "warning")
        return redirect(url_for("conferences"))
    return render_template("conference_sessions.html", conference=conf, sessions=sessions)


@app.get("/sessions")
def sessions():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT session_id, title, conference_id FROM Session ORDER BY session_id"
        ).fetchall()
    return render_template("sessions.html", sessions=rows)


@app.route("/sessions/new", methods=["GET", "POST"])
def new_session():
    with get_connection() as conn:
        conferences = conn.execute(
            "SELECT conference_id, name FROM Conference ORDER BY conference_id"
        ).fetchall()

    if request.method == "POST":
        conference_id = request.form.get("conference_id", "").strip()
        title = request.form.get("title", "").strip()

        if not conference_id.isdigit():
            flash("Please choose a valid conference.", "warning")
            return redirect(url_for("new_session"))
        if not title:
            flash("Title cannot be empty.", "warning")
            return redirect(url_for("new_session"))

        with get_connection() as conn:
            conn.execute(
                """
                INSERT INTO Session (session_id, conference_id, title)
                VALUES (
                    COALESCE((SELECT MAX(session_id) + 1 FROM Session), 1),
                    ?, ?
                )
                """,
                (int(conference_id), title),
            )
            conn.commit()

        flash("New session created successfully.", "success")
        return redirect(url_for("sessions"))

    return render_template("new_session.html", conferences=conferences)


@app.post("/sessions/<int:session_id>/delete")
def delete_session(session_id: int):
    """Match CLI behavior: remove M:N links first, then delete the session."""
    with get_connection() as conn:
        conn.execute("DELETE FROM SessionRoomAssignment WHERE session_id = ?", (session_id,))
        conn.execute("DELETE FROM SpeakerAssignment WHERE session_id = ?", (session_id,))
        cur = conn.execute("DELETE FROM Session WHERE session_id = ?", (session_id,))
        conn.commit()

    if cur.rowcount == 0:
        flash("No session found with that ID.", "warning")
    else:
        flash(f"Session {session_id} and its related assignments were deleted.", "success")
    return redirect(url_for("sessions"))


@app.get("/speakers")
def speakers():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT speaker_id, name, affiliation, email FROM Speaker ORDER BY speaker_id"
        ).fetchall()
    return render_template("speakers.html", speakers=rows)


@app.post("/speakers/new")
def new_speaker():
    """Create a new speaker.

    Kept intentionally simple for Phase 3: validates required fields and
    relies on DB constraints (e.g., UNIQUE email) for integrity.
    """
    name = request.form.get("name", "").strip()
    affiliation = request.form.get("affiliation", "").strip() or None
    email = request.form.get("email", "").strip() or None

    if not name:
        flash("Speaker name cannot be empty.", "warning")
        return redirect(url_for("speakers"))

    try:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT INTO Speaker (speaker_id, name, email, affiliation)
                VALUES (
                    COALESCE((SELECT MAX(speaker_id) + 1 FROM Speaker), 1),
                    ?, ?, ?
                )
                """,
                (name, email, affiliation),
            )
            conn.commit()
        flash("Speaker added successfully.", "success")
    except sqlite3.IntegrityError:
        # Most common: email uniqueness violation.
        flash("Could not add speaker. The email may already exist.", "warning")

    return redirect(url_for("speakers"))


@app.post("/speakers/<int:speaker_id>/delete")
def delete_speaker(speaker_id: int):
    """Delete a speaker.

    Match CLI-style behavior: remove M:N links first to satisfy FK constraints.
    """
    with get_connection() as conn:
        conn.execute("DELETE FROM SpeakerAssignment WHERE speaker_id = ?", (speaker_id,))
        cur = conn.execute("DELETE FROM Speaker WHERE speaker_id = ?", (speaker_id,))
        conn.commit()

    if cur.rowcount == 0:
        flash("No speaker found with that ID.", "warning")
    else:
        flash(f"Speaker {speaker_id} and related assignments were deleted.", "success")
    return redirect(url_for("speakers"))


@app.route("/assign/speaker", methods=["GET", "POST"])
def assign_speaker():
    with get_connection() as conn:
        sess_rows = conn.execute("SELECT session_id, title FROM Session ORDER BY session_id").fetchall()
        spk_rows = conn.execute("SELECT speaker_id, name FROM Speaker ORDER BY speaker_id").fetchall()

    if request.method == "POST":
        session_id = request.form.get("session_id", "").strip()
        speaker_id = request.form.get("speaker_id", "").strip()

        if not (session_id.isdigit() and speaker_id.isdigit()):
            flash("Please choose a valid session and speaker.", "warning")
            return redirect(url_for("assign_speaker"))

        try:
            with get_connection() as conn:
                conn.execute(
                    "INSERT INTO SpeakerAssignment (session_id, speaker_id) VALUES (?, ?)",
                    (int(session_id), int(speaker_id)),
                )
                conn.commit()
            flash("Speaker successfully assigned to session.", "success")
        except sqlite3.IntegrityError:
            flash("This assignment already exists or invalid IDs were provided.", "warning")

        return redirect(url_for("assign_speaker"))

    with get_connection() as conn:
        assignments = conn.execute(
            """
            SELECT sa.session_id, s.title AS session_title, sa.speaker_id, sp.name AS speaker_name
            FROM SpeakerAssignment sa
            JOIN Session s ON sa.session_id = s.session_id
            JOIN Speaker sp ON sa.speaker_id = sp.speaker_id
            ORDER BY sa.session_id, sa.speaker_id
            """
        ).fetchall()

    return render_template(
        "assign_speaker.html",
        sessions=sess_rows,
        speakers=spk_rows,
        assignments=assignments,
    )


@app.post("/assign/speaker/delete")
def unassign_speaker():
    """Undo a Speaker ↔ Session assignment by deleting the junction-table row."""
    session_id = request.form.get("session_id", "").strip()
    speaker_id = request.form.get("speaker_id", "").strip()

    if not (session_id.isdigit() and speaker_id.isdigit()):
        flash("Invalid session_id or speaker_id.", "warning")
        return redirect(url_for("assign_speaker"))

    with get_connection() as conn:
        cur = conn.execute(
            "DELETE FROM SpeakerAssignment WHERE session_id = ? AND speaker_id = ?",
            (int(session_id), int(speaker_id)),
        )
        conn.commit()

    if cur.rowcount == 0:
        flash("No such speaker assignment found.", "warning")
    else:
        flash("Speaker unassigned from session.", "success")
    return redirect(url_for("assign_speaker"))


@app.get("/schedules")
def schedules():
    """List room schedule slots, optionally filtered by ?date=YYYY-MM-DD."""
    date_str = request.args.get("date", "").strip()
    if date_str and not parse_date_yyyy_mm_dd(date_str):
        flash("Invalid date format. Use YYYY-MM-DD.", "warning")
        return redirect(url_for("schedules"))

    with get_connection() as conn:
        rooms = conn.execute(
            "SELECT room_id, name FROM Room ORDER BY room_id"
        ).fetchall()
        if date_str:
            rows = conn.execute(
                """
                SELECT rs.schedule_id, r.name AS room_name, rs.date, rs.start_time, rs.end_time, rs.status
                FROM RoomSchedule rs
                JOIN Room r ON rs.room_id = r.room_id
                WHERE rs.date = ?
                ORDER BY rs.start_time
                """,
                (date_str,),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT rs.schedule_id, r.name AS room_name, rs.date, rs.start_time, rs.end_time, rs.status
                FROM RoomSchedule rs
                JOIN Room r ON rs.room_id = r.room_id
                ORDER BY rs.date, rs.start_time
                """
            ).fetchall()

    return render_template("schedules.html", schedules=rows, date_filter=date_str, rooms=rooms)


@app.post("/schedules/new")
def create_schedule_slot():
    """Create a new RoomSchedule slot."""
    room_id = request.form.get("room_id", "").strip()
    date_str = request.form.get("date", "").strip()
    start_time = request.form.get("start_time", "").strip()
    end_time = request.form.get("end_time", "").strip()
    status = request.form.get("status", "Available").strip() or "Available"

    if not room_id.isdigit():
        flash("Please choose a valid room.", "warning")
        return redirect(url_for("schedules"))
    if not parse_date_yyyy_mm_dd(date_str):
        flash("Invalid date format. Use YYYY-MM-DD.", "warning")
        return redirect(url_for("schedules"))
    if not start_time or not end_time:
        flash("Start and end time are required.", "warning")
        return redirect(url_for("schedules"))
    if status not in ("Available", "Reserved", "Completed"):
        flash("Invalid status.", "warning")
        return redirect(url_for("schedules"))

    try:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT INTO RoomSchedule (schedule_id, room_id, date, start_time, end_time, status)
                VALUES (
                    COALESCE((SELECT MAX(schedule_id) + 1 FROM RoomSchedule), 1),
                    ?, ?, ?, ?, ?
                )
                """,
                (int(room_id), date_str, start_time, end_time, status),
            )
            conn.execute(
                """
                INSERT INTO LogEntry (user, action, entity_affected)
                VALUES (?, ?, ?)
                """,
                ("Scheduler", f"Created schedule slot for room {room_id} on {date_str} {start_time}-{end_time} ({status})", "RoomSchedule"),
            )
            conn.commit()
        flash("Room schedule slot created.", "success")
    except sqlite3.IntegrityError as e:
        flash(f"Could not create schedule slot: {e}", "warning")

    return redirect(url_for("schedules"))


@app.post("/schedules/<int:schedule_id>/delete")
def delete_schedule_slot(schedule_id: int):
    """Delete a RoomSchedule slot (and any SessionRoomAssignment links)."""
    with get_connection() as conn:
        # Remove M:N links first (Session ↔ RoomSchedule)
        conn.execute("DELETE FROM SessionRoomAssignment WHERE schedule_id = ?", (schedule_id,))
        cur = conn.execute("DELETE FROM RoomSchedule WHERE schedule_id = ?", (schedule_id,))
        conn.execute(
            """
            INSERT INTO LogEntry (user, action, entity_affected)
            VALUES (?, ?, ?)
            """,
            ("Scheduler", f"Deleted schedule slot {schedule_id}", "RoomSchedule"),
        )
        conn.commit()

    if cur.rowcount == 0:
        flash("No schedule slot found with that ID.", "warning")
    else:
        flash(f"Schedule slot {schedule_id} deleted (and related placements removed).", "success")
    return redirect(url_for("schedules"))


@app.route("/assign/session-room", methods=["GET", "POST"])
def assign_session_room():
    with get_connection() as conn:
        sess_rows = conn.execute("SELECT session_id, title FROM Session ORDER BY session_id").fetchall()
        sched_rows = conn.execute(
            """
            SELECT rs.schedule_id, r.name AS room_name, rs.date, rs.start_time, rs.end_time, rs.status
            FROM RoomSchedule rs
            JOIN Room r ON rs.room_id = r.room_id
            ORDER BY rs.date, rs.start_time
            """
        ).fetchall()

    if request.method == "POST":
        session_id = request.form.get("session_id", "").strip()
        schedule_id = request.form.get("schedule_id", "").strip()

        if not (session_id.isdigit() and schedule_id.isdigit()):
            flash("Please choose a valid session and schedule slot.", "warning")
            return redirect(url_for("assign_session_room"))

        try:
            with get_connection() as conn:
                conn.execute(
                    "INSERT INTO SessionRoomAssignment (session_id, schedule_id) VALUES (?, ?)",
                    (int(session_id), int(schedule_id)),
                )
                conn.commit()
            flash("Session assigned to schedule slot successfully.", "success")
        except sqlite3.IntegrityError:
            flash("This session is already assigned to that schedule or IDs are invalid.", "warning")

        return redirect(url_for("assign_session_room"))

    with get_connection() as conn:
        assignments = conn.execute(
            """
            SELECT sra.session_id, s.title AS session_title,
                   sra.schedule_id, r.name AS room_name, rs.date, rs.start_time, rs.end_time
            FROM SessionRoomAssignment sra
            JOIN Session s ON sra.session_id = s.session_id
            JOIN RoomSchedule rs ON sra.schedule_id = rs.schedule_id
            JOIN Room r ON rs.room_id = r.room_id
            ORDER BY rs.date, rs.start_time
            """
        ).fetchall()

    return render_template(
        "assign_session_room.html",
        sessions=sess_rows,
        schedules=sched_rows,
        assignments=assignments,
    )


@app.post("/assign/session-room/delete")
def unassign_session_room():
    """Undo a Session ↔ RoomSchedule placement by deleting the junction-table row."""
    session_id = request.form.get("session_id", "").strip()
    schedule_id = request.form.get("schedule_id", "").strip()

    if not (session_id.isdigit() and schedule_id.isdigit()):
        flash("Invalid session_id or schedule_id.", "warning")
        return redirect(url_for("assign_session_room"))

    with get_connection() as conn:
        cur = conn.execute(
            "DELETE FROM SessionRoomAssignment WHERE session_id = ? AND schedule_id = ?",
            (int(session_id), int(schedule_id)),
        )
        conn.commit()

    if cur.rowcount == 0:
        flash("No such placement found.", "warning")
    else:
        flash("Session unassigned from schedule slot.", "success")
    return redirect(url_for("assign_session_room"))


@app.post("/schedules/<int:schedule_id>/status")
def update_schedule_status(schedule_id: int):
    new_status = request.form.get("status", "").strip()
    if new_status not in ("Available", "Reserved", "Completed"):
        flash("Invalid status.", "warning")
        return redirect(url_for("schedules"))

    with get_connection() as conn:
        conn.execute(
            "UPDATE RoomSchedule SET status = ? WHERE schedule_id = ?",
            (new_status, schedule_id),
        )
        conn.execute(
            """
            INSERT INTO LogEntry (user, action, entity_affected)
            VALUES (?, ?, ?)
            """,
            ("Scheduler", f"Updated schedule {schedule_id} to {new_status}", "RoomSchedule"),
        )
        conn.commit()

    flash("Schedule status updated and logged.", "success")
    return redirect(url_for("schedules"))


@app.get("/logs")
def logs():
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT log_id, user, timestamp, action, entity_affected
            FROM LogEntry
            ORDER BY timestamp DESC
            """
        ).fetchall()
    return render_template("logs.html", logs=rows)


if __name__ == "__main__":
    app.run(debug=True)
